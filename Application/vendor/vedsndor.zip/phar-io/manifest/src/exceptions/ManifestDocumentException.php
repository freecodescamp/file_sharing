<?php declare(strict_types = 1);
namespace PharIo\Manifest;

class ManifestDocumentException extends \RuntimeException implements Exception {
}
