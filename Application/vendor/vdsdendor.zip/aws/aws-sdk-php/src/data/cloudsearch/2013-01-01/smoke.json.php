<?php
// This file was auto-generated from sdk-root/src/data/cloudsearch/2013-01-01/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'DescribeDomains', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'DescribeIndexFields', 'input' => [ 'DomainName' => 'fakedomain', ], 'errorExpectedFromService' => true, ], ],];
