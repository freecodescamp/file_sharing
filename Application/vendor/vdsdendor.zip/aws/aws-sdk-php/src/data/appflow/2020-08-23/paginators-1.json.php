<?php
// This file was auto-generated from sdk-root/src/data/appflow/2020-08-23/paginators-1.json
return [ 'pagination' => [ 'DescribeConnectorProfiles' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', ], 'DescribeConnectors' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', ], 'DescribeFlowExecutionRecords' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', ], 'ListFlows' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', ], ],];
