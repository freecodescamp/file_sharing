.. note::

  This service is only available for Rackspace users.

Setup
-----

.. include:: /services/common/rs-client.rst
