Setup
-----

In order to interact with this feature you must first retrieve a particular
load balancer, like so:

.. code-block:: php

  $loadBalancer = $service->loadBalancer('{id}');
