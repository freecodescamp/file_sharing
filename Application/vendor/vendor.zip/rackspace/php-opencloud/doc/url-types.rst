URL types
=========

internalURL
-----------

An internal URL is a URL that is accessible only from within the Rackspace
Cloud network. Access to an internal URL is always free of charge.


publicURL
---------

A public URL is a URL that is accessible from anywhere. Access to a public URL
usually incurs traffic charges.
