
<?php $__env->startSection('title', 'Backblaze Settings'); ?>
<?php $__env->startSection('content'); ?>
<div class="backblaze_page">
  <div class="note note-danger print-error-msg mt-3" style="display:none"><span></span></div>
  <div class="note note-warning">
    <?php echo e(__('If you are handling large files we recommend you to use Wasabi or Amazon S3, B2 storage is good for files less than 50MB')); ?>

  </div>
    <div class="card">
      <div class="card-header">
        <small class="text-muted"><?php echo e(__('You can get your details from')); ?> 
        <a href="https://secure.backblaze.com/b2_buckets.htm" target="_blank"><?php echo e(__('Backblaze console')); ?></a></small>
        <span class="col-auto ms-auto d-print-none">
        <img src="<?php echo e(asset('images/sections/backblaze-logo.gif')); ?>" width="130">
        </span>
      </div>
        <div class="card-body">
            <form id="backblazeForm" method="POST">
              <div class="form-group">
                <label for="b2_bucket"><?php echo e(__('Bucket Name :')); ?></label>
                <input type="text" name="b2_bucket" id="b2_bucket" class="form-control" value="<?php echo e($backblaze->b2_bucket ?? ""); ?>">
              </div>
              <div class="form-group">
                <label for="b2_account_id"><?php echo e(__('Account ID :')); ?></label>
                <input type="text" name="b2_account_id" id="b2_account_id" class="form-control" value="<?php echo e($backblaze->b2_account_id ?? ""); ?>">
              </div>
              <div class="form-group">
                <label for="b2_application_key"><?php echo e(__('Application key :')); ?></label>
                <input type="text" name="b2_application_key" id="b2_application_key" class="form-control" value="<?php echo e($backblaze->b2_application_key ?? ""); ?>">
              </div>
              <div class="form-group">
                <label for="b2_url"><?php echo e(__('Backblaze  URL :')); ?></label>
                <input type="text" name="b2_url" id="b2_url" class="form-control" value="<?php echo e($backblaze->b2_url ?? ""); ?>">
                <small class="text-muted"><?php echo e(__('Enter url without "/" in the end')); ?></small>
              </div>
              <button id="backblazeSaveBtn" class="backblazeBtn btn btn-primary"><?php echo e(__('Save changes')); ?></button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\software\htdocs\MediaFile\Application\resources\views/admin/backblaze.blade.php ENDPATH**/ ?>