<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
   <head>
      <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </head>
   <?php if($ads->mobile_ads != null): ?>
   <?php echo $ads->mobile_ads; ?>

   <?php endif; ?>
   <body <?php if(Request::path()== "/"): ?> class="filebob_home_body" <?php endif; ?> <?php if(\Request::segment(1) == 'ib'): ?> class="bg-white" <?php endif; ?>>
   <?php if(Request::path()== "/"): ?>
   <script>
      "use strict";
        const SITE_URL              = "<?php echo e(url('/')); ?>";
        const MAX_FILES             = <?php echo e($settings->onetime_uploads); ?>;
        const MAX_SIZE              = <?php echo e($settings->max_filesize); ?>;
        const BIG_FILES_DETECTED    = "This File Type not Allowed."; 
   </script>
   <?php endif; ?>
   <?php if(\Request::segment(1) == "download"): ?>
   <script>
      "use strict";
      const DOWN_URL              = "<?php echo e(route('download.action', $file->file_id ?? "")); ?>";
      const DOWN_TXT              = "<?php echo e(__('Download File ('.formatBytes($file->file_size ?? "").')')); ?>";
   </script>
   <?php endif; ?>
   <?php if($__env->yieldContent('title') != "Page not found"): ?>
   <header class="navbar navbar-expand-md navbar-light d-print-none <?php if(\Request::segment(1) == 'download'): ?> sticky-top <?php endif; ?>">
      <div class="<?php if(\Request::segment(1) == "download"): ?> container <?php else: ?>  container-fluid <?php endif; ?>">
         <?php if(\Request::segment(1) != 'addition'): ?> 
         <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar-menu">
         <span class="navbar-toggler-icon"></span>
         </button>
         <?php endif; ?>
         <h1 class="navbar-brand navbar-brand-autodark d-none-navbar-horizontal <?php if(\Request::segment(1) != 'addition'): ?> me-md-3 <?php endif; ?>">
            <a href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('images/main/'.$settings->logo)); ?>" width="110" height="32" alt="<?php echo e($settings->site_name); ?>" class="navbar-brand-image">
            </a> <?php if(\Request::segment(1) == 'addition'): ?> <span class="filebob__setup text-muted"> <?php echo e(__('| SetUp')); ?></span> <?php endif; ?>
         </h1>
         <div class="navbar-nav flex-row order-md-last">
            <?php if(auth()->guard()->guest()): ?>
            <li class="nav-item pe-0 pe-md-2 d-mobile-none">
               <a href="<?php echo e(url('/login')); ?>" class="btn">
                  <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                     <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                     <path d="M14 8v-2a2 2 0 0 0 -2 -2h-7a2 2 0 0 0 -2 2v12a2 2 0 0 0 2 2h7a2 2 0 0 0 2 -2v-2" />
                     <path d="M20 12h-13l3 -3m0 6l-3 -3" />
                  </svg>
                  <?php echo e(__('Sign in')); ?>

               </a>
            </li>
            <?php if(Route::has('register')): ?>
            <li class="nav-item d-mobile-none">
               <a href="<?php echo e(url('/register')); ?>" class="btn btn-primary">
                  <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                     <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                     <circle cx="9" cy="7" r="4" />
                     <path d="M3 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2" />
                     <path d="M16 11h6m-3 -3v6" />
                  </svg>
                  <?php echo e(__('Create account')); ?>

               </a>
            </li>
            <?php endif; ?>
            <li class="nav-item pe-1 d-md-none mobile-icon">
               <a href="<?php echo e(url('/login')); ?>">
                  <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                     <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                     <path d="M14 8v-2a2 2 0 0 0 -2 -2h-7a2 2 0 0 0 -2 2v12a2 2 0 0 0 2 2h7a2 2 0 0 0 2 -2v-2" />
                     <path d="M20 12h-13l3 -3m0 6l-3 -3" />
                  </svg>
               </a>
            </li>
            <?php else: ?>
            <?php if(\Request::segment(1) != 'addition'): ?> 
            <li class="nav-item pe-0 pe-md-3 d-mobile-none">
               <a href="<?php echo e(url('user/files')); ?>" class="btn">
                  <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M9 4h3l2 2h5a2 2 0 0 1 2 2v7a2 2 0 0 1 -2 2h-10a2 2 0 0 1 -2 -2v-9a2 2 0 0 1 2 -2" /><path d="M17 17v2a2 2 0 0 1 -2 2h-10a2 2 0 0 1 -2 -2v-9a2 2 0 0 1 2 -2h2" /></svg>
                  <?php echo e(__('File Manager')); ?>

               </a>
            </li>
            <?php endif; ?>
            <div class="nav-item dropdown">
               <a href="#" class="nav-link d-flex lh-1 text-reset p-0" data-bs-toggle="dropdown" aria-label="Open user menu">
                  <span class="avatar avatar-sm" style="background-image: url(<?php echo e(asset('path/cdn/avatars/'.Auth::user()->avatar)); ?>)"></span>
                  <div class="d-none d-xl-block ps-2">
                     <div><?php echo e(Auth::user()->name); ?></div>
                     <div class="mt-1 small text-muted">
                        <?php if(Auth::user()->permission == 2): ?> <?php echo e(__('User')); ?> <?php elseif(Auth::user()->permission == 1): ?> <?php echo e(__('Admin')); ?> <?php endif; ?>
                     </div>
                  </div>
               </a>
               <div class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                  <?php if(\Request::segment(1) != 'addition'): ?> 
                  <a href="<?php echo e(url('user/dashboard')); ?>" class="dropdown-item"><?php echo e(__('Dashboard')); ?></a>
                  <a href="<?php echo e(url('user/files')); ?>" class="dropdown-item"><?php echo e(__('File Manager')); ?></a>
                  <a href="<?php echo e(url('user/settings')); ?>" class="dropdown-item"><?php echo e(__('Settings')); ?></a>
                  <div class="dropdown-divider"></div>
                  <?php endif; ?>
                  <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><?php echo e(__('Logout')); ?></a>
                  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                     <?php echo csrf_field(); ?>
                  </form>
               </div>
            </div>
            <?php endif; ?>
         </div>
         <?php if(\Request::segment(1) != 'addition'): ?> 
         <div class="collapse navbar-collapse order-md-first" id="navbar-menu">
            <div class="d-flex flex-column flex-md-row flex-fill align-items-stretch align-items-md-center">
               <ul class="navbar-nav">
                  <li class="nav-item <?php if(Request::path()== '/'): ?> active <?php endif; ?>">
                     <a class="nav-link" href="<?php echo e(url('/')); ?>">
                        <span class="nav-link-icon d-md-none d-lg-inline-block">
                           <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                              <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                              <polyline points="5 12 3 12 12 3 21 12 19 12" />
                              <path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-7" />
                              <path d="M9 21v-6a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v6" />
                           </svg>
                        </span>
                        <span class="nav-link-title"><?php echo e(__('Home')); ?></span>
                     </a>
                  </li>
                  <li class="nav-item dropdown <?php if(\Request::segment(1) == 'page'): ?> active <?php endif; ?>">
                     <a class="nav-link dropdown-toggle" href="#navbar-third" data-bs-toggle="dropdown" role="button" aria-expanded="false">
                        <span class="nav-link-icon d-md-none d-lg-inline-block">
                           <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                              <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                              <circle cx="12" cy="12" r="9" />
                              <line x1="12" y1="8" x2="12.01" y2="8" />
                              <polyline points="11 12 12 12 12 16 13 16" />
                           </svg>
                        </span>
                        <span class="nav-link-title d-lg-none d-xl-inline-block"><?php echo e(__('About')); ?></span>
                     </a>
                     <div class="dropdown-menu">
                        <?php if($composerPages->count() > 0): ?>
                        <?php $__currentLoopData = $composerPages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $composerPage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="dropdown-item  <?php if(\Request::segment(2) == $composerPage->slug): ?> active <?php endif; ?>" href="<?php echo e(url('page/'.$composerPage->slug)); ?>"><?php echo e($composerPage->title); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?> 
                        <div class="text-center"><?php echo e(__('No Pages')); ?></div>
                        <?php endif; ?>
                     </div>
                  </li>
                  <?php if(Request::path()== '/'): ?>
                  <li class="nav-item">
                     <a class="nav-link" href="#modal-full-width" data-bs-toggle="modal" data-bs-target="#modal-full-width">
                        <span class="nav-link-icon d-md-none d-lg-inline-block">
                           <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                              <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                              <path d="M7 18a4.6 4.4 0 0 1 0 -9a5 4.5 0 0 1 11 2h1a3.5 3.5 0 0 1 0 7h-1" />
                              <polyline points="9 15 12 12 15 15" />
                              <line x1="12" y1="12" x2="12" y2="21" />
                           </svg>
                        </span>
                        <span class="nav-link-title d-lg-none d-xl-inline-block"><?php echo e(__('Upload')); ?></span>
                     </a>
                  </li>
                  <?php else: ?> 
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/')); ?>">
                        <span class="nav-link-icon d-md-none d-lg-inline-block">
                           <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                              <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                              <path d="M7 18a4.6 4.4 0 0 1 0 -9a5 4.5 0 0 1 11 2h1a3.5 3.5 0 0 1 0 7h-1" />
                              <polyline points="9 15 12 12 15 15" />
                              <line x1="12" y1="12" x2="12" y2="21" />
                           </svg>
                        </span>
                        <span class="nav-link-title"><?php echo e(__('Upload')); ?></span>
                     </a>
                  </li>
                  <?php endif; ?>
               </ul>
            </div>
         </div>
         <?php endif; ?>
      </div>
   </header>
   <?php endif; ?>
   <?php echo $__env->yieldContent('content'); ?>
   <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </body>
</html><?php /**PATH C:\software\htdocs\MediaFile\Application\resources\views/layouts/pages.blade.php ENDPATH**/ ?>