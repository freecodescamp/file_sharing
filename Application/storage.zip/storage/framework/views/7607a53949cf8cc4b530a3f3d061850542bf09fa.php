<script src="<?php echo e(asset('assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script><?php /**PATH C:\software\htdocs\MediaFile\Application\resources\views/install/includes/footer.blade.php ENDPATH**/ ?>