
<?php $__env->startSection('title', 'Settings'); ?>
<?php $__env->startSection('content'); ?>
<div class="note note-danger print-error-msg mt-3" style="display:none"><span></span></div>
<div class="ibob_settings">
   <div class="card">
      <ul class="nav nav-tabs" data-bs-toggle="tabs">
         <li class="nav-item">
            <a href="#info" class="p-3 nav-link active" data-bs-toggle="tab">
            <?php echo e(__('Website information')); ?></a>
         </li>
         <li class="nav-item">
            <a href="#ogofav" class="p-3 nav-link" data-bs-toggle="tab">
            <?php echo e(__('Logo & Favicon')); ?></a>
         </li>
         <li class="nav-item">
            <a href="#api" class="p-3 nav-link" data-bs-toggle="tab">
            <?php echo e(__('Api')); ?></a>
         </li>
         <li class="nav-item">
            <a href="#seo" class="p-3 nav-link" data-bs-toggle="tab">
            <?php echo e(__('SEO')); ?></a>
         </li>
      </ul>
      <div class="card-body">
         <div class="tab-content">
            <div class="tab-pane active show" id="info">
               <form method="POST">
                  <div class="row">
                     <div class="col-lg-6">
                        <div class="form-group">
                           <label for="site_name"><?php echo e(__('Website Name :')); ?><span class="fsgred">*</span></label>
                           <input type="text" name="site_name" id="site_name" class="form-control" placeholder="Enter site name" required value="<?php echo e($settings->site_name ?? ""); ?>">
                        </div>
                     </div>
                     <div class="col-lg-6">
                        <div class="form-group">
                           <label for="storage"><?php echo e(__('Uploads storage :')); ?><span class="fsgred">*</span></label>
                           <select name="storage" id="storage" class="form-select">
                           <option value="1" <?php if($settings->storage == 1): ?> selected <?php endif; ?>><?php echo e(__('Local server')); ?></option>
                           <option value="2" <?php if($settings->storage == 2): ?> selected <?php endif; ?>><?php echo e(__('Amazon S3')); ?></option>
                           <option value="3" <?php if($settings->storage == 3): ?> selected <?php endif; ?>><?php echo e(__('Wasabi S3')); ?></option>
                           <option value="4" <?php if($settings->storage == 4): ?> selected <?php endif; ?>><?php echo e(__('Backblaze')); ?></option>
                           </select>
                        </div>
                     </div>
                  </div>
                  <div class="form-group">
                     <label for="site_analytics"><?php echo e(__('Google analytics :')); ?></label>
                     <input type="text" name="site_analytics" id="site_analytics" class="form-control" placeholder="Enter google analytics code" required value="<?php echo e($settings->site_analytics ?? ""); ?>">
                  </div>
                  <div class="form-group">
                     <label for="home_heading"><?php echo e(__('Home page heading :')); ?><span class="fsgred">*</span></label>
                     <input type="text" name="home_heading" id="home_heading" class="form-control" placeholder="Enter home page heading" required value="<?php echo e($settings->home_heading ?? ""); ?>">
                  </div>
                  <div class="form-group">
                     <label for="home_descritption"><?php echo e(__('Home page descritption :')); ?><span class="fsgred">*</span></label>
                     <textarea name="home_descritption" id="home_descritption" class="form-control" rows="3" placeholder="Enter home page descritption" required><?php echo e($settings->home_descritption ?? ""); ?></textarea>
                  </div>
                  <div class="row">
                     <div class="col-lg-6">
                        <div class="form-group">
                           <label for="max_filesize"><?php echo e(__('Max file size (MB) :')); ?><span class="fsgred">*</span></label>
                           <input type="number" name="max_filesize" id="max_filesize" class="form-control" placeholder="0" required value="<?php echo e($settings->max_filesize ?? "0"); ?>">
                        </div>
                     </div>
                     <div class="col-lg-6">
                        <div class="form-group">
                           <label for="onetime_uploads"><?php echo e(__('One time uploads :')); ?><span class="fsgred">*</span></label>
                           <input type="number" name="onetime_uploads" id="onetime_uploads" class="form-control" placeholder="0" required value="<?php echo e($settings->onetime_uploads ?? "0"); ?>">
                        </div>
                     </div>
                  </div>
                  <button id="saveInfoBtn" class="infoBtn btn btn-primary"><?php echo e(__('Save changes')); ?></button>
               </form>
            </div>
            <div class="tab-pane" id="ogofav">
               <form method="POST" enctype="multipart/form-data">
                  <div class="image">
                     <?php if($settings != null): ?>
                     <div class="text-center logobox <?php if($settings->logo == null): ?> d-none <?php endif; ?>">
                        <img id="preview_logo" src="<?php if($settings->logo != null): ?><?php echo e(asset('images/main/'.$settings->logo)); ?><?php endif; ?>" width="110">
                     </div>
                     <?php endif; ?>
                     <div class="form-group">
                        <label for="logo"><?php echo e(__('Logo :')); ?> <span class="fsgred">*</span></label>
                        <input type="file" name="logo" id="logo" class="form-control" required>
                        <small class="text-muted"><?php echo e(__('You can upload any size but the size we recommend')); ?> (110x32)</small>
                     </div>
                  </div>
                  <div class="image">
                     <?php if($settings != null): ?>
                     <div class="text-center favbox <?php if($settings->favicon == null): ?> d-none <?php endif; ?>">
                        <img id="preview_favicon" src="<?php if($settings->favicon != null): ?><?php echo e(asset('images/main/'.$settings->favicon)); ?><?php endif; ?>" width="60">
                     </div>
                     <?php endif; ?>
                     <div class="form-group">
                        <label for="favicon"><?php echo e(__('Favicon :')); ?> <span class="fsgred">*</span></label>
                        <input type="file" name="favicon" id="favicon" class="form-control" required>
                        <small class="text-muted"><?php echo e(__('Recommend')); ?> (60x60)</small>
                     </div>
                  </div>
                  <button id="saveLogoFavBtn" class="btn btn-primary"><?php echo e(__('Save changes')); ?></button>
               </form>
            </div>
            <div class="tab-pane" id="api">
               <div>
                  <form method="POST">
                     <div class="row">
                        <div class="col-lg-6">
                           <div class="inte-box">
                              <h2><?php echo e(__('Facebook')); ?></h2>
                              <div class="form-group">
                                 <label for="facebook_clientid"><?php echo e(__('CLIENT ID :')); ?></label>
                                 <input type="text" name="facebook_clientid" id="facebook_clientid" class="form-control" value="<?php echo e($api->facebook_clientid ?? ""); ?>">
                              </div>
                              <div class="form-group">
                                 <label for="facebook_clientsecret"><?php echo e(__('CLIENT SECRET :')); ?></label>
                                 <input type="text" name="facebook_clientsecret" id="facebook_clientsecret" class="form-control" value="<?php echo e($api->facebook_clientsecret ?? ""); ?>">
                              </div>
                              <div class="form-group">
                                 <label for="facebook_reurl"><?php echo e(__('REDIRECT URL :')); ?></label>
                                 <input type="text" name="facebook_reurl" id="facebook_reurl" class="form-control" value="<?php echo e($api->facebook_reurl ?? ""); ?>">
                                 <small class="text-muted"><?php echo e(__('Use this :')); ?> <?php echo e(url('/third-party/facebook/callback')); ?></small>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-6">
                           <div class="inte-box">
                              <h2><?php echo e(__('Google Captcha ')); ?><small class="text-muted"><?php echo e(__('Please use version V2 "Im not a robot"')); ?></small></h2>
                              <div class="form-group">
                                 <label for="google_key"><?php echo e(__('SITEKEY :')); ?></label>
                                 <input type="text" name="google_key" id="google_key" class="form-control" value="<?php echo e($api->google_key ?? ""); ?>">
                              </div>
                              <div class="form-group">
                                 <label for="google_secret"><?php echo e(__('SECRET :')); ?></label>
                                 <input type="text" name="google_secret" id="google_secret" class="form-control" value="<?php echo e($api->google_secret ?? ""); ?>">
                              </div>
                           </div>
                        </div>
                     </div>
                     <button id="saveApiBtn" class="apiBtn btn btn-primary"><?php echo e(__('Save changes')); ?></button>
                  </form>
               </div>
            </div>
            <div class="tab-pane" id="seo">
               <form method="POST">
                  <div class="form-group">
                     <label for="seo_title"><?php echo e(__('Home title :')); ?> <span class="fsgred">*</span></label>
                     <input type="text" name="seo_title" id="seo_title" class="form-control" placeholder="Enter home page title" value="<?php echo e($seo->seo_title ?? ""); ?>">
                  </div>
                  <div class="row">
                     <div class="col-lg-6">
                        <div class="form-group">
                           <label for="seo_description"><?php echo e(__('Description :')); ?></label>
                           <textarea name="seo_description" id="seo_description" rows="6" class="form-control" placeholder="Enter description"><?php echo e($seo->seo_description ?? ""); ?></textarea>
                        </div>
                     </div>
                     <div class="col-lg-6">
                        <div class="form-group">
                           <label for="seo_keywords"><?php echo e(__('Keywords :')); ?></label>
                           <textarea name="seo_keywords" id="seo_keywords" rows="6" class="form-control" placeholder="tag, tag, tag"><?php echo e($seo->seo_keywords ?? ""); ?></textarea>
                        </div>
                     </div>
                  </div>
                  <button id="saveSeoBtn" class="seoBtn btn btn-primary"><?php echo e(__('Save changes')); ?></button>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\software\htdocs\MediaFile\Application\resources\views/admin/settings.blade.php ENDPATH**/ ?>