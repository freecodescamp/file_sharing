
<script src="<?php echo e(asset('assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/sweetalert/sweetalert.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/jqvmap/dist/jquery.vmap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/progressbar/progressbar.js')); ?>"></script>
<?php if(Request::path() != "admin/dashboard"): ?>
<script src="<?php echo e(asset('assets/js/admin/main.js')); ?>"></script>
<?php endif; ?>
<?php if(Request::path() == "admin/dashboard"): ?>
<script src="<?php echo e(asset('assets/libs/apexcharts/dist/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/admin/charts.js')); ?>"></script>
<?php endif; ?>
<?php if(\Request::segment(2) == "pages"): ?>
<script src="<?php echo e(asset('assets/libs/ckeditor/ckeditor.js')); ?>"></script>
<script>
$(function($){
    'use strict';
    var $ckfield = CKEDITOR.replace( 'content' );
    $ckfield.on('change', function() {
      $ckfield.updateElement();         
    });
});
</script>
<?php endif; ?>

<?php /**PATH C:\software\htdocs\MediaFile\Application\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>