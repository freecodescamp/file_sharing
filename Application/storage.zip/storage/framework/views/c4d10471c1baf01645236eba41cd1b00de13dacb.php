
<?php $__env->startSection('title', 'Messages'); ?>
<?php $__env->startSection('content'); ?>
<div class="ibob_messages">
   <?php if($messages->count() > 0): ?>
   <div class="card">
      <div class="card-body">
         <div class="divide-y-4">
            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="deletemessage<?php echo e($message->id); ?> <?php if($message->status == 1): ?>viewmessage <?php endif; ?> new__message">
               <div class="row">
                  <div class="col-auto">
                     <?php if($message->user_id != null): ?>
                     <span class="avatar" style="background-image: url(<?php echo e(asset('path/cdn/avatars/'.$message->user->avatar)); ?>)"></span>
                     <?php else: ?> 
                     <span class="avatar" style="background-image: url(<?php echo e(asset('path/cdn/avatars/default.png')); ?>)"></span>
                     <?php endif; ?>
                  </div>
                  <div class="col">
                     <div class="text-truncate">
                        <strong><?php echo e($message->name); ?></strong> <?php echo e(__('sent messages about')); ?> <strong><a class="text-dark" href="<?php echo e(route('view.message', $message->id)); ?>">"<?php echo e($message->subject); ?>"</a></strong>.
                     </div>
                     <div class="text-muted"><?php echo e($message->email); ?></div>
                  </div>
                  <?php if($message->status == 1): ?>
                  <div class="unread<?php echo e($message->id); ?> col-auto align-self-center">
                     <div class="badge bg-primary"></div>
                  </div>
                  <?php endif; ?>
                  <div class="col-auto align-self-center">
                     <span class="text-muted"><?php echo e(Carbon\Carbon::parse($message->created_at)->diffForHumans()); ?></span>
                     <a href="#" data-id="<?php echo e($message->id); ?>" id="deleteMsg" class="btn btn-danger btn-sm ms-3">
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon m-0" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                           <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                           <line x1="4" y1="7" x2="20" y2="7" />
                           <line x1="10" y1="11" x2="10" y2="17" />
                           <line x1="14" y1="11" x2="14" y2="17" />
                           <path d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12" />
                           <path d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3" />
                        </svg>
                     </a>
                  </div>
               </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </div>
      </div>
   </div>
   <?php echo e($messages->links()); ?>

   <?php else: ?> 
   <div class="empty">
      <div class="empty-img">
         <img src="<?php echo e(asset('images/sections/empty.svg')); ?>" height="128" alt="">
      </div>
      <p class="empty-title"><?php echo e(__('No data found')); ?></p>
      <p class="empty-subtitle text-muted">
         <?php echo e(__('This section is empty and has no content.')); ?>

      </p>
   </div>
   <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\software\htdocs\MediaFile\Application\resources\views/admin/messages.blade.php ENDPATH**/ ?>