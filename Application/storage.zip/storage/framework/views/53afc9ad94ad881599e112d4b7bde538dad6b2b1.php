
<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?> 
<div class="filebob_dash mt-3">
   <?php if($uploads->count() > 0): ?>
   <div class="card">
      <div class="card-header border-0">
         <div class="card-title"><?php echo e(__('Uploads Activity')); ?></div><br>
      </div>
      <div class="card-body">
         <div id="chart-uploads-activity"></div>
      </div>
      <div class="table-responsive mb-0">
         <table class="table card-table table-vcenter">
            <thead>
               <tr>
                  <th><?php echo e(__('File')); ?></th>
                  <th><?php echo e(__('Commit')); ?></th>
                  <th><?php echo e(__('Date')); ?></th>
               </tr>
            </thead>
            <tbody>
               <?php $__currentLoopData = $uploads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upload): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
                  <td class="w-1">
                     <span><img src="<?php echo e(fileIcon($upload->file_type)); ?>"></span>
                  </td>
                  <td class="td-truncate">
                     <div class="text-truncate">
                        <?php echo e(__('File uploaded')); ?> ( <a href="<?php echo e(route('download.file', $upload->file_id)); ?>" target="_blank"><?php echo e(route('download.file', $upload->file_id)); ?></a> )
                     </div>
                  </td>
                  <td class="text-nowrap text-muted"><?php echo date('d/m/Y  H:i A', strtotime($upload->created_at)); ?></td>
               </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
         </table>
      </div>
   </div>
   <div class="text-center mt-3">
   <a href="<?php echo e(url('user/files')); ?>" class="btn"><?php echo e(__('View All uploads')); ?></a>
   </div>
   <?php else: ?> 
   <div class="empty">
      <div class="empty-img"><img src="<?php echo e(asset('images/sections/empty.svg')); ?>" height="128" alt="">
      </div>
      <p class="empty-title"><?php echo e(__('No activity found')); ?></p>
      <p class="empty-subtitle text-muted">
         <?php echo e(__('Start uploading files and your recent activities will be visible here.')); ?>

      </p>
      <div class="empty-action">
         <a href="<?php echo e(url('/')); ?>" class="btn">
            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
               <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
               <path d="M7 18a4.6 4.4 0 0 1 0 -9a5 4.5 0 0 1 11 2h1a3.5 3.5 0 0 1 0 7h-1"></path>
               <polyline points="9 15 12 12 15 15"></polyline>
               <line x1="12" y1="12" x2="12" y2="21"></line>
           </svg>
           <?php echo e(__('Start Uploading')); ?>

         </a>
       </div>
    </div>
   <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\software\htdocs\MediaFile\Application\resources\views/pages/user/dashboard.blade.php ENDPATH**/ ?>