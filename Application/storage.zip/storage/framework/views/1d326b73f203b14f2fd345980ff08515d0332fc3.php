<meta charset="UTF-8">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<?php if(\Request::segment(1) != "user" && \Request::segment(1) != "download"): ?>
<meta name="description" content="<?php echo e($seo->seo_description ?? ""); ?>">
<meta name="keywords" content="<?php echo e($seo->seo_keywords?? ""); ?>">
<meta property="og:title" content="<?php echo e($seo->seo_title ?? ""); ?>" />
<meta property="og:type" content="website" />
<meta property="og:site_name" content="<?php echo e($settings->site_name ?? ""); ?>" />
<meta property="og:url" content="<?php echo e(url('/')); ?>" />
<meta property="og:image" content="<?php echo e(asset('images/main/'.$settings->logo)); ?>" />
<meta name="twitter:card" content="summary">
<meta name="twitter:description" content="<?php echo e($seo->seo_description ?? ""); ?>">
<meta name="twitter:title" content="<?php echo e($settings->site_name); ?> — <?php echo e($seo->seo_title); ?>">
<meta name="twitter:site" content="<?php echo e(url('/')); ?>">
<?php endif; ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title><?php echo e($settings->site_name); ?> — <?php echo $__env->yieldContent('title'); ?></title>
<link href="<?php echo e(asset('images/main/'.$settings->favicon)); ?>" rel="shortcut icon">
<link href="<?php echo e(asset('images/main/'.$settings->favicon)); ?>" type="image/png" rel="icon" sizes="192x192">
<link rel="apple-touch-icon" href="<?php echo e(asset('images/main/'.$settings->favicon)); ?>" sizes="180x180">
<link href="<?php echo e(asset('assets/libs/jqvmap/dist/jqvmap.min.css')); ?>" rel="stylesheet"/>
<link href="<?php echo e(asset('assets/fontawesome/font-awesome.min.css')); ?>" rel="stylesheet"/>
<link href="<?php echo e(asset('assets/fontawesome/font-awesome-animation.min.css')); ?>" rel="stylesheet"/>
<link href="<?php echo e(asset('assets/libs/dropzone/dropzone.min.css')); ?>" rel="stylesheet"/>
<link href="<?php echo e(asset('assets/css/app.css')); ?>" rel="stylesheet"/>
<link href="<?php echo e(asset('assets/css/app-vendors.css')); ?>" rel="stylesheet"/>
<link href="<?php echo e(asset('assets/css/ibob.css')); ?>" rel="stylesheet"/>
<?php if(\Request::segment(2) == "files"): ?>
<link href="<?php echo e(asset('assets/css/user/main.css')); ?>" rel="stylesheet"/>
<?php endif; ?><?php /**PATH C:\software\htdocs\MediaFile\Application\resources\views/includes/head.blade.php ENDPATH**/ ?>