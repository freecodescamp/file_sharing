
<?php $__env->startSection('title', 'Website ADS'); ?>
<?php $__env->startSection('content'); ?>
<div class="amazons3_page">
   <form id="adsForm" method="POST">
      <div class="card mb-3">
         <div class="card-header bg-info text-white">
            <h3 class="m-0"><?php echo e(__('Home & user & mobile Ads')); ?></h3>
         </div>
         <div class="card-body">
            <div class="row">
               <div class="col-lg-6">
                  <div class="form-group">
                     <label for="home_ads_top"><?php echo e(__('Home page top ads:')); ?></label>
                     <textarea class="form-control" id="home_ads_top" name="home_ads_top" rows="10"><?php echo e($ads->home_ads_top ?? ""); ?></textarea>
                     <small class="text-muted"><?php echo e(__('Use Synchronous ad and it will be showing (728x90 On Desktop) and (300x280 On Mobile)')); ?></small>
                  </div>
               </div>
               <div class="col-lg-6">
                  <div class="form-group">
                     <label for="home_ads_bottom"><?php echo e(__('Home page bottom ads :')); ?></label>
                     <textarea class="form-control" id="home_ads_bottom" name="home_ads_bottom" rows="10"><?php echo e($ads->home_ads_bottom ?? ""); ?></textarea>
                     <small class="text-muted"><?php echo e(__('Use Synchronous ad and it will be showing (982x280 On Desktop) and (300x280 On Mobile)')); ?></small>
                  </div>
               </div>
               <div class="col-lg-6">
                  <div class="form-group">
                     <label for="mobile_ads"><?php echo e(__('Mobile Ads :')); ?></label>
                     <textarea class="form-control" id="mobile_ads" name="mobile_ads" rows="10"><?php echo e($ads->mobile_ads ?? ""); ?></textarea>
                     <small class="text-muted"><?php echo e(__('Head code')); ?></small>
                  </div>
               </div>
               <div class="col-lg-6">
                  <div class="form-group">
                     <label for="user_account_ads"><?php echo e(__('User account ads :')); ?></label>
                     <textarea class="form-control" id="user_account_ads" name="user_account_ads" rows="10"><?php echo e($ads->user_account_ads ?? ""); ?></textarea>
                     <small class="text-muted"><?php echo e(__('Use Synchronous ad and it will be showing (728x90 On Desktop) and (300x280 On Mobile)')); ?></small>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="card mb-3">
         <div class="card-header bg-success text-white">
            <h3 class="m-0"><?php echo e(__('Download page ads')); ?></h3>
         </div>
         <div class="card-body">
            <div class="row">
                <div class="col-lg-6">
                   <div class="form-group">
                      <label for="download_top_ads"><?php echo e(__('Download file top Ads:')); ?></label>
                      <textarea class="form-control" id="download_top_ads" name="download_top_ads" rows="10"><?php echo e($ads->download_top_ads ?? ""); ?></textarea>
                      <small class="text-muted"><?php echo e(__('Use (728x90)')); ?></small>
                   </div>
                </div>
                <div class="col-lg-6">
                   <div class="form-group">
                      <label for="download_left_top_ads"><?php echo e(__('Download file left top Ads :')); ?></label>
                      <textarea class="form-control" id="download_left_top_ads" name="download_left_top_ads" rows="10"><?php echo e($ads->download_left_top_ads ?? ""); ?></textarea>
                      <small class="text-muted"><?php echo e(__('Use (300x280)')); ?></small>
                   </div>
                </div>
                <div class="col-lg-12">
                   <div class="form-group">
                      <label for="download_left_bottom_ads"><?php echo e(__('Download file left bottom Ads :')); ?></label>
                      <textarea class="form-control" id="download_left_bottom_ads" name="download_left_bottom_ads" rows="10"><?php echo e($ads->download_left_bottom_ads ?? ""); ?></textarea>
                      <small class="text-muted"><?php echo e(__('Use (300x280)')); ?></small>
                   </div>
                </div>
             </div>
         </div>
      </div>
      <div class="card">
         <div class="card-body">
            <div class="note note-danger print-error-msg mb-3" style="display:none"><span></span></div>
            <button class="btnAds btn btn-primary" id="saveAdsBtn"><?php echo e(__('Save changes')); ?></button>
         </div>
      </div>
   </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\software\htdocs\MediaFile\Application\resources\views/admin/ads.blade.php ENDPATH**/ ?>