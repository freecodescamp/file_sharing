<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title>Imgbob — Install - <?php echo $__env->yieldContent('title'); ?></title>
<link href="<?php echo e(asset('images/main/favicon.ico')); ?>" rel="icon">
<link href="<?php echo e(asset('assets/libs/jqvmap/dist/jqvmap.min.css')); ?>" rel="stylesheet"/>
<link href="<?php echo e(asset('assets/fontawesome/font-awesome.min.css')); ?>" rel="stylesheet"/>
<link href="<?php echo e(asset('assets/libs/dropzone/dropzone.min.css')); ?>" rel="stylesheet"/>
<link href="<?php echo e(asset('assets/css/app.css')); ?>" rel="stylesheet"/>
<link href="<?php echo e(asset('assets/css/app-vendors.css')); ?>" rel="stylesheet"/>
<link href="<?php echo e(asset('assets/css/ibob.css')); ?>" rel="stylesheet"/>
<?php /**PATH C:\software\htdocs\MediaFile\Application\resources\views/install/includes/head.blade.php ENDPATH**/ ?>