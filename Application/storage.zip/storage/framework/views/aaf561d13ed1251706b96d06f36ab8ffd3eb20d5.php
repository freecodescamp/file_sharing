<?php $__env->startSection('title', 'Sign up'); ?>
<?php $__env->startSection('content'); ?>
<div class="flex-fill d-flex flex-column justify-content-center py-5">
   <div class="container-tight py-6">
      <form class="card card-md" method="POST" action="<?php echo e(route('register')); ?>">
         <?php echo csrf_field(); ?>
         <div class="card-body">
            <h2 class="card-title text-center mb-4"><?php echo e(__('Create new account')); ?></h2>
            <div class="mb-3">
               <label class="form-label"><?php echo e(__('Full Name')); ?></label>
               <input id="name" type="fullname" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter your full name" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
               <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
               <span class="invalid-feedback" role="alert">
               <strong><?php echo e($message); ?></strong>
               </span>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">
               <label class="form-label"><?php echo e(__('Email address')); ?></label>
               <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter email address" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
               <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
               <span class="invalid-feedback" role="alert">
               <strong><?php echo e($message); ?></strong>
               </span>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">
               <label class="form-label"><?php echo e(__('Password')); ?></label>
               <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter password" name="password" required autocomplete="new-password">
               <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
               <span class="invalid-feedback" role="alert">
               <strong><?php echo e($message); ?></strong>
               </span>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">
               <label class="form-label"><?php echo e(__('Confirm password')); ?></label>
               <input id="password-confirm" type="password" class="form-control" name="password_confirmation" placeholder="Confirm password" required autocomplete="new-password">
            </div>
            <div class="mb-3">
               <label class="form-check">
               <input type="checkbox" name="agree" class="form-check-input <?php $__errorArgs = ['agree'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required <?php echo e(old('agree') ? 'checked' : ''); ?>/>
               <span class="form-check-label"><?php echo e(__('I agree with terms and policy.')); ?></span>
               </label>
               <?php $__errorArgs = ['agree'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
               <span class="invalid-feedback" role="alert">
               <strong><?php echo e($message); ?></strong>
               </span>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group<?php echo e($errors->has('g-recaptcha-response') ? ' has-error' : ''); ?>">
               <?php echo app('captcha')->display(); ?>

               <?php if($errors->has('g-recaptcha-response')): ?>
                  <span class="help-block">
                     <strong><?php echo e($errors->first('g-recaptcha-response')); ?></strong>
                  </span>
               <?php endif; ?>
             </div>
            <button type="submit" class="btn btn-primary w-100 btn-pd"><?php echo e(__('Create new account')); ?></button>
         </div>
         <?php if(env('FACEBOOK_CLIENT_ID') != null && env('FACEBOOK_CLIENT_SECRET') != null && env('FACEBOOK_REDIRECT_URL') != null ): ?>
         <div class="hr-text"><?php echo e(__('or')); ?></div>
         <div class="card-body">
            <div class="row">
               <div class="col">
                  <a href="<?php echo e(route('third-party.action', 'facebook')); ?>" class="btn btn-white w-100 btn-pd">
                     <svg xmlns="http://www.w3.org/2000/svg" class="icon text-blue" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                        <path d="M7 10v4h3v7h4v-7h3l1 -4h-4v-2a1 1 0 0 1 1 -1h3v-4h-3a5 5 0 0 0 -5 5v2h-3" />
                     </svg>
                     <?php echo e(__('SignUp with facebook')); ?>

                  </a>
               </div>
            </div>
         </div>
         <?php endif; ?>
      </form>
      <div class="text-center text-muted mt-3">
         <?php echo e(__('Already have account?')); ?> <a href="<?php echo e(url('/login')); ?>" tabindex="-1"><?php echo e(__('Login')); ?></a>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.pages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\software\htdocs\MediaFile\Application\resources\views/auth/register.blade.php ENDPATH**/ ?>