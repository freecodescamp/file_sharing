
<?php $__env->startSection('title', $page->title); ?>
<?php $__env->startSection('content'); ?>
<div class="page_header">
   <h1><?php echo e($page->title); ?></h1>
</div>
<div class="flex-fill d-flex flex-column justify-content-center py-4">
   <div class="container py-6">
      <?php if($page->slug != "contact"): ?>
      <div class="card card-md">
         <div class="card-body">
            <h3 class="card-title"><?php echo e($page->title); ?></h3>
            <div class="markdown">
               <?php echo $page->content; ?>

            </div>
         </div>
      </div>
      <?php else: ?> 
      <?php if($errors->any()): ?>
      <div class="note note-danger">
         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <li><?php echo e($error); ?></li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <?php endif; ?>
      <?php if(session('success')): ?>
      <div class="note note-success">
         <?php echo e(session('success')); ?>

      </div>
      <?php endif; ?>
      <div class="card card-md">
         <div class="card-body">
            <h3 class="card-title"><?php echo e(__('Contact')); ?> Us</h3>
            <form action="<?php echo e(route('send.msg')); ?>" method="POST">
               <?php echo csrf_field(); ?>
               <div class="row">
                  <div class="col-lg-6">
                     <div class="form-group">
                        <input type="text" id="name" name="name" class="form-control"  placeholder="Your Name" required="required" value="<?php echo e(Auth::user()->name ?? ""); ?>">
                     </div>
                  </div>
                  <div class="col-lg-6">
                     <div class="form-group">
                        <input type="email" id="email" name="email" class="form-control" placeholder="Your Email" required="required" value="<?php echo e(Auth::user()->email ?? ""); ?>">
                     </div>
                  </div>
               </div>
               <div class="form-group">
                  <input type="text" id="subject" name="subject" class="form-control" placeholder="Subject" required="required">
               </div>
               <div class="form-group">
                  <textarea class="form-control" id="message" name="message" placeholder="Message" required="required" rows="8"></textarea>
               </div>
               <div class="form-group">
                  <?php echo app('captcha')->display(); ?>

               </div>
               <div>
                  <button type="submit" class="btn btn-primary btn-pd" id="sendMessageButton"><?php echo e(__('Send Message')); ?></button>
               </div>
            </form>
         </div>
      </div>
      <?php endif; ?>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.pages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\software\htdocs\MediaFile\Application\resources\views/pages/page.blade.php ENDPATH**/ ?>