
<?php $__env->startSection('title', 'Step 2'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body text-center">
        <h4 class="card-title mb-2"><?php echo e(__('Great Job :)')); ?> </h4>
        <p><?php echo e(__('There is more few steps to make your website works')); ?></p>
        <p class="text-muted"><?php echo e(__('Now lets get your website ready.')); ?></p>
        <form action="<?php echo e(route('install/step2/import_database')); ?>" method="POST" class="my-login-validation" novalidate="">
            <?php echo csrf_field(); ?>
            <div class="form-group m-0">
                <button type="submit" name="logBtn" class="btn btn-primary btn-block btn-pd"> <?php echo e(__('Get Started')); ?></button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.install', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\software\htdocs\MediaFile\Application\resources\views/install/step2.blade.php ENDPATH**/ ?>