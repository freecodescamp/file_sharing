<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <?php echo $__env->make('install.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body>
        <section class="py-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 m-auto">
                    <div class="install text-center mb-3">
                    <img src="<?php echo e(asset('images/sections/configuration.svg')); ?>" width="120">
                    </div>
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>
            </div>
        </section>
    </div>
     <?php echo $__env->make('install.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\software\htdocs\MediaFile\Application\resources\views/layouts/install.blade.php ENDPATH**/ ?>