<?php if($__env->yieldContent('title') != "Page not found"): ?>
<footer class="footer footer-transparent d-print-none">
   <div class="<?php if(\Request::segment(1) == "ib"): ?> container-fluid <?php else: ?> container <?php endif; ?>">
      <div class="text-center">
         <ul class="list-inline list-inline-dots mb-0 ms-0">
            <li class="list-inline-item">
               <?php echo e(__('Copyright ©')); ?> <script>document.write(new Date().getFullYear())</script>
               <a href="<?php echo e(url('/')); ?>" class="link-secondary"><?php echo e($settings->site_name); ?></a>.
               <?php echo e(__('All rights reserved.')); ?>

            </li>
         </ul>
      </div>
   </div>
</footer>
<?php endif; ?>
<script src="<?php echo e(asset('assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/sweetalert/sweetalert.min.js')); ?>"></script>
<?php if(Request::path()== "user/dashboard"): ?>
<?php if($uploads->count() > 0): ?>
<script src="<?php echo e(asset('assets/libs/apexcharts/dist/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/jqvmap/dist/jquery.vmap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/user/charts.js')); ?>"></script>
<?php endif; ?>
<?php endif; ?>
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
<?php if(Request::path()== "/"): ?>
<script src="<?php echo e(asset('assets/libs/dropzone/dropzone.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/home/ibob.js')); ?>"></script>
<?php endif; ?>
<?php if(\Request::segment(1) == "user" or \Request::segment(1) == "admin"): ?>
<script src="<?php echo e(asset('assets/js/progressbar/progressbar.js')); ?>"></script>
<?php endif; ?>
<?php if(\Request::segment(1) == "download"): ?>
<script src="<?php echo e(asset('assets/js/download.js')); ?>"></script>
<?php endif; ?>
<?php if(\Request::segment(1) == "user"): ?>
<script src="<?php echo e(asset('assets/js/user/main.js')); ?>"></script>
<?php endif; ?>
<?php echo NoCaptcha::renderJs(); ?>

<?php if($settings->site_analytics != null): ?>
<script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo e($settings->site_analytics); ?>"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', '<?php echo e($settings->site_analytics); ?>');
</script>
<?php endif; ?><?php /**PATH C:\software\htdocs\MediaFile\Application\resources\views/includes/footer.blade.php ENDPATH**/ ?>