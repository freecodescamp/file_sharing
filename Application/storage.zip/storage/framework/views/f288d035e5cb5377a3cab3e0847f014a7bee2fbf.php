
<?php $__env->startSection('title', 'Add page'); ?>
<?php $__env->startSection('content'); ?>
<div class="note note-danger print-error-msg" style="display:none"><span></span></div>
<div class="alert alert-info">
    <?php echo e(__('Contact US page was created by default you can add it to your website using')); ?> <strong>contact</strong> <?php echo e(__(' slug.')); ?>

</div>
<div class="card">
    <div class="card-body">
        <form id="addPageForm" method="POST">
            <div class="form-group">
              <label for="title"><?php echo e(__('Page Title :')); ?> <span class="fsgred">*</span></label>
              <input type="text" name="title" id="title" class="form-control" placeholder="Enter page title">
            </div>
            <div class="form-group">
                <label for="slug"><?php echo e(__('Page Slug :')); ?> <span class="fsgred">*</span></label>
                <div class="input-group">
                   <span class="input-group-text"><?php echo e(url('page/')); ?>/</span>
                   <input type="text" name="slug" id="slug" class="remove-spaces form-control" placeholder="slug">
                </div>
            </div>
            <div class="form-group">
                <label for="content"><?php echo e(__('Page Content :')); ?></label>
                <textarea class="form-control" name="content" id="content" rows="10"></textarea>
            </div>
            <button class="addPageBtn btn btn-primary" id="addPageBtn"><?php echo e(__('Add page')); ?></button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\software\htdocs\MediaFile\Application\resources\views/admin/add/page.blade.php ENDPATH**/ ?>